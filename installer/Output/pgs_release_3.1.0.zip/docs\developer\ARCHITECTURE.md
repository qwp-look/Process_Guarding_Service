# 技术架构

本文面向开发者，解释 PGS 的实现边界和主要组件。操作命令请看 [普通用户操作指南](../user/USER_GUIDE.md) 或 [维护者操作指南](../operator/OPERATOR_GUIDE.md)。

## 组件

- `PGS`：服务核心，负责认证、协议、守护状态、监控、重启、模块调用。
- `pgs_service`：Windows 服务宿主，负责 install/start/stop/uninstall/run。
- `pgs_bless`：CLI 运维入口。
- `pgs_admin_qt`：Qt 桌面管理端。
- `pgs_admin_web`：Web 管理端。
- `pgs_cluster_web`：Cluster dashboard。
- `ModuleManager`：加载和调用 ABI 模块。

## 状态模型

PGS 把守护对象当成“逻辑 guard”，而不是单个 PID。进程重启后 PID 会变，但 guardId 和策略继续存在。

持久化状态包含：

- guard desired-state。
- token hash。
- 重启计数和窗口时间戳。
- 高级策略字段。
- 模块 permissive 状态。

状态文件版本当前为 v3。旧版本加载时会补默认字段。

默认持久化文件位于：

```text
C:\ProgramData\ProcessGuard\state\pgs_guard_state.db
```

文件是 tab 分隔文本，主要记录 `VERSION`、`NEXT_GUARD_ID`、`AUTH_TOKEN_HASH`、`MODULES_PERMISSIVE`、`GUARD`、`RESTART_COUNT`、`RESTART`。路径、restart args 和 AUMID 使用 base64，便于保留空格和非 ASCII 内容。

## 监控和重启

PGS 使用 Job Object 管理进程族，并通过 IOCP 接收退出通知。IOCP 是快速唤醒路径，句柄轮询仍作为兜底。

`kill-on-exit` 默认关闭，保证 PGS 自身崩溃或被 SCM 重启时，守护进程可以继续存活并被复接管。用户显式开启时，PGS 退出会连同守护进程族一起结束。

重启流程按 guardId 维护窗口计数。`restart-delay` 会延迟拉起；`restart-backoff` 基于该延迟做指数退避；超过 `restart-window` 内的上限后，guard 会退休并从持久状态移除。

## 启动路径

普通 Win32 程序：

- `bless-start` 使用 CLI 启动后注册。
- 服务端异常恢复时按保存的 path/args 在目标 session 中拉起。

WindowsApps：

- 当前只支持显式 AUMID attach。
- 重启走 AUMID activation。
- 自动 manifest 推导和 `bless-start --winapp` 尚未完成。

## UI 边界

Qt 管理端偏本机普通用户。Web 管理端偏浏览器和远程维护。Cluster dashboard 只做多节点查看与节点管理，不替代单机守护核心。

Web remote 必须 TLS + users file + audit log。Cluster 非回环监听必须 TLS + dashboard API token。

## 模块边界

模块是 Windows DLL，导出 C ABI。PGS 通过 `LoadLibrary` 和 `PG_Invoke` 调用。模块默认按需加载；PPL 和全量扫描需要 opt-in。

模块目录受 allowlist 和路径限制保护。完整模块开发细节见 [模块系统](MODULE_SYSTEM.md)。

## 协议边界

协议是文本行协议，不是 protobuf/grpc。当前通过契约测试固定核心响应；protobuf 迁移不是本轮目标，后续视复杂度再评估。

协议细节见 [协议与契约](PROTOCOL.md)。
